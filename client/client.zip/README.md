## Backend Setup

### Prerequisites
- Install npm

### Installation & Setup
1. npm install
2. npm run dev