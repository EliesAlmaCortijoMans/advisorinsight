default_app_config = 'stock.apps.StockConfig'
